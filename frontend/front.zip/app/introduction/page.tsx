import Footer from "../components/Footer";
import Introduction from "../components/Introduction/Introduction";
import Background from "../components/Background/Background";

export default function () {
    return (
        <>
        <Introduction/>
        <Background/>
        <Footer/>
        </>
    );
}