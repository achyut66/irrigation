declare global {
    interface Window {
      google: any;
    }
  }
  
  export {};
  