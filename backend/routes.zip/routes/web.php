<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthenticatedSessionController;


// Route::post('/login', [AuthenticatedSessionController::class, 'login']);
// Route::post('/logout', [AuthenticatedSessionController::class, 'logout'])
//     ->middleware('auth:sanctum');
Route::get('/sanctum/csrf-cookie', function () {
    return response()->json(['csrf' => csrf_token()]);
});
Route::get('/', function () {
    return response()->json([
        'message' => 'Laravel backend is running'
    ]);
});

require __DIR__.'/auth.php';
